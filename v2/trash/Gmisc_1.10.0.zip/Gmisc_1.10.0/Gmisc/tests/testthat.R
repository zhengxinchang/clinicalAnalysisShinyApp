library('testthat')

test_check('Gmisc')
